import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone } from 'lucide-react';

const navLinks = [
  { name: 'Home', path: '/' },
  { name: 'About', path: '/about' },
  { name: 'Services', path: '/services' },
  { name: 'Appointments', path: '/appointments' },
  { name: 'Gallery', path: '/gallery' },
  { name: 'Contact', path: '/contact' },
];

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [location]);

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled
            ? 'bg-white shadow-lg shadow-slate-200/80 py-3'
            : 'bg-[#0B1D3A]/95 backdrop-blur-sm py-4'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-3 group">
              {/* SVG Logo Icon */}
              <div className="relative w-10 h-10 flex-shrink-0">
                <svg viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-10 h-10">
                  <rect width="40" height="40" rx="10" fill="#0EA5E9"/>
                  <path d="M20 8C16.5 8 13 10.5 13 14c0 1.8.5 3 1 4.5.8 2.5 1 5.5 2 7.5.5 1 1 2 2 2s1.5-1 2-2c.3-.8.5-1.8.7-2.8.2 1 .4 2 .7 2.8.5 1 1 2 2 2s1.5-1 2-2c1-2 1.2-5 2-7.5.5-1.5 1-2.7 1-4.5C28.4 10.5 23.5 8 20 8z" fill="white"/>
                  <circle cx="17" cy="13" r="1.2" fill="#0EA5E9"/>
                  <circle cx="23" cy="13" r="1.2" fill="#0EA5E9"/>
                </svg>
              </div>
              {/* Logo Text */}
              <div className="flex flex-col leading-tight">
                <span className={`font-bold text-lg tracking-tight leading-none transition-colors ${
                  isScrolled ? 'text-[#0B1D3A]' : 'text-white'
                }`} style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                  True Dental Care
                </span>
                <span className="text-sky-400 text-xs font-semibold tracking-widest uppercase">
                  Islamabad
                </span>
              </div>
            </Link>

            {/* Desktop Nav */}
            <nav className="hidden lg:flex items-center gap-7">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`nav-link text-sm font-semibold transition-colors duration-200 ${
                    location.pathname === link.path
                      ? 'text-sky-400'
                      : isScrolled
                      ? 'text-slate-600 hover:text-sky-500'
                      : 'text-slate-200 hover:text-sky-400'
                  } ${location.pathname === link.path ? 'active' : ''}`}
                >
                  {link.name}
                </Link>
              ))}
            </nav>

            {/* CTA & Mobile Toggle */}
            <div className="flex items-center gap-3">
              {/* Phone */}
              <a
                href="tel:+923318899227"
                className={`hidden md:flex items-center gap-1.5 text-sm font-medium transition-colors ${
                  isScrolled ? 'text-slate-600 hover:text-sky-500' : 'text-slate-200 hover:text-sky-400'
                }`}
              >
                <Phone size={14} className="text-sky-400" />
                <span>+92 331 8899227</span>
              </a>

              <Link
                to="/appointments"
                className="hidden sm:inline-flex btn-primary text-sm py-2.5 px-5"
              >
                Book Now
              </Link>

              {/* Mobile hamburger */}
              <button
                onClick={() => setMobileOpen(!mobileOpen)}
                className={`lg:hidden p-2 rounded-lg transition-colors ${
                  isScrolled ? 'text-slate-700 hover:bg-slate-100' : 'text-white hover:bg-white/10'
                }`}
                aria-label="Toggle menu"
              >
                {mobileOpen ? <X size={22} /> : <Menu size={22} />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      <div
        className={`fixed inset-0 z-40 lg:hidden transition-all duration-300 ${
          mobileOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        {/* Backdrop */}
        <div
          className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          onClick={() => setMobileOpen(false)}
        />
        {/* Drawer */}
        <div
          className={`absolute top-0 right-0 h-full w-72 bg-[#0B1D3A] shadow-2xl transition-transform duration-300 ${
            mobileOpen ? 'translate-x-0' : 'translate-x-full'
          }`}
        >
          <div className="flex items-center justify-between p-5 border-b border-white/10">
            <span className="text-white font-bold text-lg" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
              True Dental Care
            </span>
            <button onClick={() => setMobileOpen(false)} className="text-slate-300 hover:text-white p-1">
              <X size={22} />
            </button>
          </div>
          <nav className="flex flex-col p-6 gap-2">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`px-4 py-3 rounded-xl font-semibold text-sm transition-all duration-200 ${
                  location.pathname === link.path
                    ? 'bg-sky-500 text-white'
                    : 'text-slate-300 hover:bg-white/10 hover:text-white'
                }`}
              >
                {link.name}
              </Link>
            ))}
            <div className="mt-4 pt-4 border-t border-white/10 flex flex-col gap-3">
              <a
                href="tel:+923318899227"
                className="flex items-center gap-2 text-slate-300 text-sm font-medium hover:text-sky-400"
              >
                <Phone size={14} className="text-sky-400" />
                +92 331 8899227
              </a>
              <Link to="/appointments" className="btn-primary text-sm justify-center">
                Book Appointment
              </Link>
            </div>
          </nav>
        </div>
      </div>
    </>
  );
}
