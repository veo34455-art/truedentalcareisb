import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle2, Heart, Shield, Star, Award, Target, Smile } from 'lucide-react';

const qualifications = [
  'BDS (Bachelor of Dental Surgery)',
  'Certified in Advanced Cosmetic Dentistry',
  'Trained in Orthodontic Braces & Clear Aligners',
  'Root Canal Therapy Specialist',
  'Member, Pakistan Dental Association',
  'Continuing Education in Implantology',
];

const values = [
  {
    icon: <Heart size={24} className="text-sky-400" />,
    title: 'Compassionate Care',
    desc: 'We understand dental anxiety is real. Our team creates a warm, judgment-free environment where every patient feels safe and respected throughout their visit.',
  },
  {
    icon: <Shield size={24} className="text-sky-400" />,
    title: 'Clinical Excellence',
    desc: 'We uphold the highest standards of dental practice, using evidence-based techniques and sterile protocols to ensure safe, reliable outcomes for every patient.',
  },
  {
    icon: <Target size={24} className="text-sky-400" />,
    title: 'Personalized Treatment',
    desc: 'No two smiles are alike. We take the time to understand your unique dental needs and goals, crafting a treatment plan tailored specifically for you.',
  },
  {
    icon: <Star size={24} className="text-sky-400" />,
    title: 'Continuous Improvement',
    desc: 'Dentistry evolves rapidly. Dr. Wafa regularly participates in advanced training to bring the latest, most effective dental solutions to her patients.',
  },
];

export default function About() {
  return (
    <div className="pt-20">
      {/* ── PAGE HERO ── */}
      <section className="bg-gradient-to-br from-[#0B1D3A] via-[#1A3A6B] to-[#0EA5E9]/80 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-sky-400 font-semibold text-sm uppercase tracking-widest mb-3">Get to Know Us</p>
          <h1 className="text-4xl md:text-5xl font-extrabold text-white mb-4" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
            About True Dental Care
          </h1>
          <p className="text-slate-300 max-w-xl mx-auto text-base leading-relaxed">
            A modern, patient-centered dental clinic in the heart of I-8 Islamabad — where science meets compassion.
          </p>
          <div className="flex justify-center gap-2 mt-6 text-slate-400 text-sm">
            <Link to="/" className="hover:text-sky-400 transition-colors">Home</Link>
            <span>/</span>
            <span className="text-sky-400">About</span>
          </div>
        </div>
      </section>

      {/* ── DOCTOR PROFILE ── */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-14 items-center">
            {/* Doctor Photo */}
            <div className="relative">
              <div className="relative rounded-3xl overflow-hidden shadow-2xl">
                <img
                  src="/images/doctor-placeholder.jpg"
                  alt="Dr. Wafa Abdi - Dentist at True Dental Care Islamabad"
                  className="w-full h-[560px] object-cover object-top"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0B1D3A]/50 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <div className="bg-white/95 backdrop-blur-sm rounded-2xl p-4 shadow-xl">
                    <h3 className="font-extrabold text-[#0B1D3A] text-lg" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Dr. Wafa Abdi</h3>
                    <p className="text-sky-500 font-semibold text-sm">BDS | Dental Surgeon & Cosmetic Dentist</p>
                    <div className="flex items-center gap-1 mt-2">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} size={13} fill="#FACC15" className="text-yellow-400" />
                      ))}
                      <span className="text-xs text-slate-500 ml-2">Highly Rated Dentist in Islamabad</span>
                    </div>
                  </div>
                </div>
              </div>
              {/* Experience badge */}
              <div className="absolute -top-4 -right-4 w-20 h-20 bg-sky-500 rounded-full flex flex-col items-center justify-center shadow-xl">
                <span className="text-white font-extrabold text-xl leading-none">5+</span>
                <span className="text-sky-100 text-xs font-medium">Years</span>
              </div>
            </div>

            {/* Doctor Info */}
            <div>
              <p className="section-subheading">Our Lead Dentist</p>
              <h2 className="section-heading mb-4">Dr. Wafa Abdi</h2>
              <p className="text-sky-500 font-semibold text-base mb-6">BDS, Dental Surgeon | Cosmetic & Restorative Dentist</p>
              
              <div className="space-y-4 text-slate-600 leading-relaxed text-base">
                <p>
                  Dr. Wafa Abdi is the founder and lead dentist at True Dental Care Islamabad — a premier dental practice committed to delivering world-class oral healthcare in a warm, modern environment.
                </p>
                <p>
                  After completing her Bachelor of Dental Surgery (BDS), Dr. Wafa pursued advanced training in cosmetic dentistry, orthodontics, and implantology. Her philosophy is simple: every patient deserves a healthy, beautiful smile, and every treatment should be as comfortable as possible.
                </p>
                <p>
                  With over 5 years of clinical experience and more than 1,000 satisfied patients, Dr. Wafa is known for her gentle technique, attention to detail, and her ability to put even the most anxious patients at ease. She stays current with the latest advances in dentistry through ongoing professional development.
                </p>
              </div>

              {/* Qualifications */}
              <div className="mt-8">
                <h4 className="font-bold text-[#0B1D3A] mb-4 text-sm uppercase tracking-widest">Qualifications & Certifications</h4>
                <div className="grid sm:grid-cols-2 gap-2.5">
                  {qualifications.map((q, i) => (
                    <div key={i} className="flex items-start gap-2.5 text-slate-600 text-sm">
                      <CheckCircle2 size={15} className="text-sky-400 flex-shrink-0 mt-0.5" />
                      <span>{q}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex flex-wrap gap-3 mt-8">
                <Link to="/appointments" className="btn-primary">
                  Book with Dr. Wafa
                  <ArrowRight size={16} />
                </Link>
                <Link to="/services" className="btn-outline">
                  View Services
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── MISSION STATEMENT ── */}
      <section className="py-16 bg-gradient-to-r from-[#0B1D3A] to-[#1A3A6B]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="w-16 h-16 bg-sky-500/20 border border-sky-400/30 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Smile size={32} className="text-sky-400" />
          </div>
          <p className="section-subheading text-sky-400">Our Mission</p>
          <h2 className="text-3xl md:text-4xl font-extrabold text-white mb-6" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
            "To provide every patient in Islamabad with accessible, high-quality dental care that improves health, restores confidence, and creates lasting smiles."
          </h2>
          <p className="text-slate-300 leading-relaxed text-base">
            At True Dental Care, we don't just treat teeth — we build relationships. From your first visit to your final follow-up, our commitment is to your oral health, your comfort, and your overall well-being.
          </p>
        </div>
      </section>

      {/* ── CLINIC VALUES ── */}
      <section className="py-20 bg-[#F0F7FF]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <p className="section-subheading">What We Stand For</p>
            <h2 className="section-heading">Our Core Values</h2>
            <p className="text-slate-500 mt-3 max-w-lg mx-auto text-base">
              These principles guide every decision we make and every patient we serve.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((v, i) => (
              <div key={i} className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 card-hover text-center">
                <div className="w-12 h-12 bg-sky-50 rounded-xl flex items-center justify-center mx-auto mb-4">
                  {v.icon}
                </div>
                <h3 className="font-bold text-[#0B1D3A] mb-2 text-base" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                  {v.title}
                </h3>
                <p className="text-slate-500 text-sm leading-relaxed">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── ACHIEVEMENTS ── */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { icon: <Award size={24} />, value: '5+', label: 'Years of Practice' },
              { icon: <Heart size={24} />, value: '1,000+', label: 'Patients Treated' },
              { icon: <Smile size={24} />, value: '7', label: 'Dental Services' },
              { icon: <Star size={24} />, value: '5★', label: 'Average Rating' },
            ].map((item, i) => (
              <div key={i} className="text-center p-6 bg-[#F0F7FF] rounded-2xl">
                <div className="text-sky-400 flex justify-center mb-2">{item.icon}</div>
                <div className="text-3xl font-extrabold text-[#0B1D3A] mb-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>{item.value}</div>
                <div className="text-slate-500 text-sm font-medium">{item.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="py-16 bg-gradient-to-r from-sky-500 to-cyan-400">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-extrabold text-white mb-3" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
            Ready to Meet Dr. Wafa Abdi?
          </h2>
          <p className="text-white/85 mb-7 text-base">
            Schedule your first consultation and experience the True Dental Care difference.
          </p>
          <Link to="/appointments" className="inline-flex items-center gap-2 bg-white text-sky-600 hover:bg-sky-50 font-bold px-8 py-4 rounded-full text-base transition-all hover:scale-105 shadow-xl">
            Book Your Appointment
            <ArrowRight size={18} />
          </Link>
        </div>
      </section>
    </div>
  );
}
