import { Link } from 'react-router-dom';
import { CheckCircle2, Star, ArrowRight, Shield, Award, Heart, Clock, Users, Smile } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';

const services = [
  { icon: '🦷', name: 'Teeth Cleaning', desc: 'Professional scaling and polishing for a fresh, healthy smile' },
  { icon: '✨', name: 'Teeth Whitening', desc: 'Advanced whitening treatments for a radiant, confident smile' },
  { icon: '🩹', name: 'Dental Fillings', desc: 'Tooth-colored composite fillings that blend naturally' },
  { icon: '🔬', name: 'Root Canal', desc: 'Pain-free root canal therapy using modern techniques' },
  { icon: '😁', name: 'Braces', desc: 'Metal and clear orthodontic braces for a perfectly aligned smile' },
  { icon: '🦴', name: 'Dental Implants', desc: 'Permanent tooth replacement that looks and feels natural' },
  { icon: '🚨', name: 'Emergency Care', desc: '24-hour dental emergency care when you need it most' },
];

const whyChooseUs = [
  {
    icon: <Shield size={28} className="text-sky-400" />,
    title: 'Expert & Qualified',
    desc: 'Dr. Wafa Abdi brings years of specialized dental training and hands-on clinical experience to every patient interaction.',
  },
  {
    icon: <Heart size={28} className="text-sky-400" />,
    title: 'Patient-First Care',
    desc: 'We treat every patient as family. Our gentle approach ensures you feel comfortable and heard from consultation to completion.',
  },
  {
    icon: <Award size={28} className="text-sky-400" />,
    title: 'Modern Technology',
    desc: 'Our clinic is equipped with state-of-the-art dental technology for precise diagnostics and superior treatment outcomes.',
  },
  {
    icon: <Clock size={28} className="text-sky-400" />,
    title: 'Convenient Hours',
    desc: 'Open Monday through Saturday with evening appointments available, making quality dental care fit your busy schedule.',
  },
];

const stats = [
  { value: 5, suffix: '+', label: 'Years of Experience', icon: <Award size={20} className="text-sky-400" /> },
  { value: 1000, suffix: '+', label: 'Happy Patients', icon: <Users size={20} className="text-sky-400" /> },
  { value: 7, suffix: '', label: 'Dental Services', icon: <Smile size={20} className="text-sky-400" /> },
  { value: 99, suffix: '%', label: 'Satisfaction Rate', icon: <Star size={20} className="text-sky-400" /> },
];

function useCountUp(end: number, duration: number = 2000, start: boolean = false) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!start) return;
    let startTime: number | null = null;
    const step = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      setCount(Math.floor(progress * end));
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [end, duration, start]);
  return count;
}

function StatCard({ value, suffix, label, icon }: { value: number; suffix: string; label: string; icon: React.ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  const [started, setStarted] = useState(false);
  const count = useCountUp(value, 2000, started);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setStarted(true); },
      { threshold: 0.5 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div ref={ref} className="text-center">
      <div className="flex justify-center mb-2">{icon}</div>
      <div className="text-4xl font-extrabold text-white" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
        {count}{suffix}
      </div>
      <div className="text-sky-200 text-sm font-medium mt-1">{label}</div>
    </div>
  );
}

export default function Home() {
  return (
    <div className="pt-0">
      {/* ── HERO SECTION ── */}
      <section className="relative min-h-screen flex items-center overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0">
          <img
            src="/images/hero-dental.jpg"
            alt="True Dental Care Islamabad clinic interior"
            className="w-full h-full object-cover"
            loading="eager"
          />
          <div className="hero-overlay absolute inset-0" />
        </div>

        {/* Decorative shapes */}
        <div className="absolute top-1/4 right-10 w-64 h-64 bg-sky-400/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-1/4 left-10 w-48 h-48 bg-cyan-400/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-28 md:py-36">
          <div className="max-w-3xl">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-sky-500/20 border border-sky-400/30 text-sky-300 text-xs font-semibold px-4 py-2 rounded-full mb-6 backdrop-blur-sm">
              <span className="w-2 h-2 bg-sky-400 rounded-full animate-pulse" />
              Now Accepting New Patients — I-8 Markaz, Islamabad
            </div>

            {/* Headline */}
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-extrabold text-white leading-tight mb-6" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
              Your Smile,
              <br />
              <span className="bg-gradient-to-r from-sky-400 to-cyan-300 bg-clip-text text-transparent">
                Our Priority.
              </span>
            </h1>

            <p className="text-lg md:text-xl text-slate-300 leading-relaxed mb-8 max-w-xl">
              Experience exceptional dental care in a calm, modern environment. Dr. Wafa Abdi and her team are dedicated to transforming your smile with precision, compassion, and cutting-edge dentistry.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/appointments" className="btn-primary text-base py-4 px-8">
                Book Appointment
                <ArrowRight size={18} />
              </Link>
              <Link to="/services" className="border-2 border-white/30 text-white hover:bg-white/10 font-semibold px-8 py-4 rounded-full transition-all duration-300 inline-flex items-center gap-2 backdrop-blur-sm">
                Explore Services
                <ArrowRight size={18} />
              </Link>
            </div>

            {/* Trust badges */}
            <div className="flex flex-wrap gap-5 mt-10">
              {[
                'Certified & Licensed Dentist',
                'Gentle & Painless Procedures',
                'Same-Day Emergency Care',
              ].map((item) => (
                <div key={item} className="flex items-center gap-2 text-slate-200 text-sm">
                  <CheckCircle2 size={16} className="text-sky-400 flex-shrink-0" />
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom wave */}
        <div className="wave-divider">
          <svg viewBox="0 0 1440 80" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none">
            <path d="M0,40 C360,80 1080,0 1440,40 L1440,80 L0,80 Z" fill="white"/>
          </svg>
        </div>
      </section>

      {/* ── STATS SECTION ── */}
      <section className="bg-gradient-to-r from-[#0B1D3A] via-[#1A3A6B] to-[#0EA5E9] py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-10">
            {stats.map((s) => (
              <StatCard key={s.label} {...s} />
            ))}
          </div>
        </div>
      </section>

      {/* ── SERVICES PREVIEW ── */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <p className="section-subheading">What We Offer</p>
            <h2 className="section-heading">Comprehensive Dental Services</h2>
            <p className="text-slate-500 mt-4 max-w-xl mx-auto text-base leading-relaxed">
              From routine cleanings to advanced restorative procedures, we provide complete dental care for your entire family — all under one roof in I-8 Islamabad.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {services.map((service, i) => (
              <div key={i} className="service-card bg-white border border-slate-100 rounded-2xl p-6 shadow-sm hover:shadow-xl cursor-pointer group">
                <div className="text-4xl mb-4">{service.icon}</div>
                <h3 className="font-bold text-[#0B1D3A] text-base mb-2 group-hover:text-sky-500 transition-colors" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                  {service.name}
                </h3>
                <p className="text-slate-500 text-sm leading-relaxed">{service.desc}</p>
              </div>
            ))}

            {/* CTA card */}
            <div className="service-card bg-gradient-to-br from-[#0B1D3A] to-[#1A3A6B] rounded-2xl p-6 shadow-sm flex flex-col justify-between">
              <div>
                <div className="text-4xl mb-4">💬</div>
                <h3 className="font-bold text-white text-base mb-2" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                  Not Sure Which Service?
                </h3>
                <p className="text-slate-300 text-sm leading-relaxed">Book a free consultation and Dr. Wafa will guide you to the right treatment.</p>
              </div>
              <Link to="/appointments" className="mt-5 btn-primary text-sm py-2.5 justify-center">
                Book Free Consult
              </Link>
            </div>
          </div>

          <div className="text-center mt-10">
            <Link to="/services" className="btn-outline">
              View All Services
              <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* ── WHY CHOOSE US ── */}
      <section className="py-20 bg-[#F0F7FF]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-14 items-center">
            <div>
              <p className="section-subheading">Why True Dental Care</p>
              <h2 className="section-heading mb-5">
                Dentistry That Goes Beyond
                <span className="block gradient-text">the Ordinary</span>
              </h2>
              <p className="text-slate-500 leading-relaxed mb-8">
                At True Dental Care Islamabad, we believe exceptional dental care is built on trust, expertise, and genuine compassion. Every smile we treat is unique — and so is our approach.
              </p>
              <div className="grid sm:grid-cols-2 gap-5">
                {whyChooseUs.map((item, i) => (
                  <div key={i} className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100 card-hover">
                    <div className="mb-3">{item.icon}</div>
                    <h4 className="font-bold text-[#0B1D3A] mb-1.5 text-sm" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                      {item.title}
                    </h4>
                    <p className="text-slate-500 text-xs leading-relaxed">{item.desc}</p>
                  </div>
                ))}
              </div>
              <div className="mt-8 flex gap-4">
                <Link to="/about" className="btn-navy text-sm">
                  Meet Dr. Wafa
                  <ArrowRight size={16} />
                </Link>
                <Link to="/appointments" className="btn-primary text-sm">
                  Book Now
                </Link>
              </div>
            </div>

            {/* Image Side */}
            <div className="relative">
              <div className="relative rounded-3xl overflow-hidden shadow-2xl">
                <img
                  src="/images/smiling-patient.jpg"
                  alt="Happy patient at True Dental Care Islamabad"
                  className="w-full h-[500px] object-cover"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0B1D3A]/30 to-transparent" />
              </div>

              {/* Floating card */}
              <div className="absolute -bottom-6 -left-6 glass-card rounded-2xl p-4 shadow-xl border border-sky-100">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-sky-500 rounded-full flex items-center justify-center flex-shrink-0">
                    <Star size={16} className="text-white" fill="white" />
                  </div>
                  <div>
                    <div className="font-bold text-[#0B1D3A] text-sm" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                      Highly Rated Clinic
                    </div>
                    <div className="flex items-center gap-1 mt-0.5">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} size={11} className="text-yellow-400" fill="#FACC15" />
                      ))}
                      <span className="text-xs text-slate-500 ml-1">5.0/5</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Second floating card */}
              <div className="absolute -top-5 -right-5 glass-card rounded-2xl p-4 shadow-xl border border-sky-100">
                <div className="text-2xl font-extrabold text-[#0B1D3A]" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>1K+</div>
                <div className="text-xs text-slate-500 font-medium">Happy Patients</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── DOCTOR TEASER ── */}
      <section className="py-16 bg-gradient-to-r from-[#0B1D3A] to-[#1A3A6B]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="flex-shrink-0">
              <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-sky-400 shadow-xl">
                <img src="/images/doctor-placeholder.jpg" alt="Dr. Wafa Abdi - Dentist Islamabad" className="w-full h-full object-cover" />
              </div>
            </div>
            <div className="flex-1 text-center md:text-left">
              <p className="text-sky-400 font-semibold text-sm uppercase tracking-widest mb-1">Meet Your Doctor</p>
              <h3 className="text-white font-bold text-2xl md:text-3xl" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                Dr. Wafa Abdi
              </h3>
              <p className="text-slate-300 text-sm mt-2 max-w-lg">
                BDS graduate and experienced dental surgeon specializing in cosmetic, restorative, and preventive dentistry. Committed to making every patient's visit stress-free and rewarding.
              </p>
            </div>
            <Link to="/about" className="flex-shrink-0 btn-primary">
              View Full Profile
              <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* ── CTA SECTION ── */}
      <section className="py-20 bg-white">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="text-5xl mb-4 tooth-float">🦷</div>
          <p className="section-subheading">Ready to Transform Your Smile?</p>
          <h2 className="section-heading mb-4">Book Your Appointment Today</h2>
          <p className="text-slate-500 leading-relaxed mb-8">
            Don't wait for dental problems to worsen. Schedule a consultation with Dr. Wafa Abdi and take the first step toward a healthier, more confident smile.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/appointments" className="btn-primary text-base py-4 px-8">
              Book Online Now
              <ArrowRight size={18} />
            </Link>
            <a
              href="https://wa.me/923318899227?text=Hello%2C%20I%20would%20like%20to%20book%20an%20appointment."
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-[#25D366] hover:bg-[#20b857] text-white font-semibold px-8 py-4 rounded-full transition-all duration-300 hover:scale-105 text-base shadow-lg"
            >
              <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
              WhatsApp Us
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
