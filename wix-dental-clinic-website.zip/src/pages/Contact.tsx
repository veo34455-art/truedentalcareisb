import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Clock, CheckCircle2, ArrowRight, Send } from 'lucide-react';

const workingHours = [
  { day: 'Monday', hours: '1:00 PM – 8:00 PM', open: true },
  { day: 'Tuesday', hours: '1:00 PM – 8:00 PM', open: true },
  { day: 'Wednesday', hours: '1:00 PM – 8:00 PM', open: true },
  { day: 'Thursday', hours: '1:00 PM – 8:00 PM', open: true },
  { day: 'Friday', hours: '3:00 PM – 8:00 PM', open: true },
  { day: 'Saturday', hours: '1:00 PM – 8:00 PM', open: true },
  { day: 'Sunday', hours: 'Closed', open: false },
];

export default function Contact() {
  const [form, setForm] = useState({ name: '', phone: '', email: '', message: '' });
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = 'Name is required.';
    if (!form.phone.trim()) e.phone = 'Phone is required.';
    if (!form.message.trim()) e.message = 'Please enter your message.';
    return e;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    if (errors[e.target.name]) setErrors({ ...errors, [e.target.name]: '' });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    setSubmitted(true);
  };

  // Detect current day for highlighting
  const todayName = new Date().toLocaleDateString('en-US', { weekday: 'long' });

  return (
    <div className="pt-20">
      {/* ── PAGE HERO ── */}
      <section className="bg-gradient-to-br from-[#0B1D3A] via-[#1A3A6B] to-[#0EA5E9]/80 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-sky-400 font-semibold text-sm uppercase tracking-widest mb-3">Get In Touch</p>
          <h1 className="text-4xl md:text-5xl font-extrabold text-white mb-4" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
            Contact Us
          </h1>
          <p className="text-slate-300 max-w-xl mx-auto text-base leading-relaxed">
            Have a question or want to book an appointment? Our team at True Dental Care Islamabad is here to help.
          </p>
          <div className="flex justify-center gap-2 mt-6 text-slate-400 text-sm">
            <Link to="/" className="hover:text-sky-400 transition-colors">Home</Link>
            <span>/</span>
            <span className="text-sky-400">Contact</span>
          </div>
        </div>
      </section>

      {/* ── CONTACT CARDS ── */}
      <section className="py-14 bg-[#F0F7FF]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {/* Phone */}
            <a
              href="tel:+923318899227"
              className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 card-hover text-center group"
            >
              <div className="w-12 h-12 bg-sky-50 rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:bg-sky-500 transition-colors">
                <Phone size={20} className="text-sky-500 group-hover:text-white transition-colors" />
              </div>
              <h3 className="font-bold text-[#0B1D3A] text-sm mb-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Phone</h3>
              <p className="text-sky-500 font-semibold text-sm">+92 331 8899227</p>
              <p className="text-slate-400 text-xs mt-1">Click to call us</p>
            </a>

            {/* WhatsApp */}
            <a
              href="https://wa.me/923318899227"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 card-hover text-center group"
            >
              <div className="w-12 h-12 bg-green-50 rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:bg-[#25D366] transition-colors">
                <svg viewBox="0 0 24 24" className="w-5 h-5 text-[#25D366] group-hover:text-white transition-colors" fill="currentColor">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
              </div>
              <h3 className="font-bold text-[#0B1D3A] text-sm mb-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>WhatsApp</h3>
              <p className="text-[#25D366] font-semibold text-sm">+92 331 8899227</p>
              <p className="text-slate-400 text-xs mt-1">Quick responses</p>
            </a>

            {/* Email */}
            <a
              href="mailto:truedentalcare.isb@gmail.com"
              className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 card-hover text-center group"
            >
              <div className="w-12 h-12 bg-purple-50 rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:bg-purple-500 transition-colors">
                <Mail size={20} className="text-purple-500 group-hover:text-white transition-colors" />
              </div>
              <h3 className="font-bold text-[#0B1D3A] text-sm mb-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Email</h3>
              <p className="text-purple-500 font-semibold text-xs break-all">truedentalcare.isb@gmail.com</p>
              <p className="text-slate-400 text-xs mt-1">We reply within 24hrs</p>
            </a>

            {/* Address */}
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 text-center">
              <div className="w-12 h-12 bg-orange-50 rounded-xl flex items-center justify-center mx-auto mb-4">
                <MapPin size={20} className="text-orange-500" />
              </div>
              <h3 className="font-bold text-[#0B1D3A] text-sm mb-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Location</h3>
              <p className="text-slate-500 text-xs leading-relaxed">Pakland Business Center, behind KFC, below Soneri Bank, I-8 Markaz, Islamabad</p>
            </div>
          </div>
        </div>
      </section>

      {/* ── MAIN CONTENT ── */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* ── CONTACT FORM ── */}
            <div>
              <p className="section-subheading">Send a Message</p>
              <h2 className="section-heading mb-2">We'd Love to Hear From You</h2>
              <p className="text-slate-500 text-sm mb-7 leading-relaxed">
                Fill out the form below and our team will get back to you within one business day.
              </p>

              {submitted ? (
                <div className="bg-green-50 border border-green-200 rounded-2xl p-8 text-center">
                  <CheckCircle2 size={40} className="text-green-500 mx-auto mb-4" />
                  <h3 className="font-bold text-green-800 text-lg mb-2">Message Sent!</h3>
                  <p className="text-green-700 text-sm mb-5">
                    Thank you, <strong>{form.name}</strong>! We've received your message and will be in touch soon.
                  </p>
                  <button
                    onClick={() => { setSubmitted(false); setForm({ name: '', phone: '', email: '', message: '' }); }}
                    className="btn-outline text-sm"
                  >
                    Send Another Message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid sm:grid-cols-2 gap-5">
                    <div>
                      <label className="text-xs font-bold text-[#0B1D3A] uppercase tracking-wider mb-1.5 block">
                        Your Name <span className="text-red-400">*</span>
                      </label>
                      <input
                        type="text"
                        name="name"
                        value={form.name}
                        onChange={handleChange}
                        placeholder="Full Name"
                        className={`form-input ${errors.name ? 'border-red-400' : ''}`}
                      />
                      {errors.name && <p className="text-red-400 text-xs mt-1">{errors.name}</p>}
                    </div>
                    <div>
                      <label className="text-xs font-bold text-[#0B1D3A] uppercase tracking-wider mb-1.5 block">
                        Phone Number <span className="text-red-400">*</span>
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        value={form.phone}
                        onChange={handleChange}
                        placeholder="+92 3XX XXXXXXX"
                        className={`form-input ${errors.phone ? 'border-red-400' : ''}`}
                      />
                      {errors.phone && <p className="text-red-400 text-xs mt-1">{errors.phone}</p>}
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-[#0B1D3A] uppercase tracking-wider mb-1.5 block">
                      Email Address <span className="text-slate-400 font-normal">(optional)</span>
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={form.email}
                      onChange={handleChange}
                      placeholder="your@email.com"
                      className="form-input"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-[#0B1D3A] uppercase tracking-wider mb-1.5 block">
                      Your Message <span className="text-red-400">*</span>
                    </label>
                    <textarea
                      name="message"
                      value={form.message}
                      onChange={handleChange}
                      rows={5}
                      placeholder="Tell us about your dental concern, question, or how we can help you..."
                      className={`form-input resize-none ${errors.message ? 'border-red-400' : ''}`}
                    />
                    {errors.message && <p className="text-red-400 text-xs mt-1">{errors.message}</p>}
                  </div>

                  <button type="submit" className="btn-primary w-full justify-center py-4 text-base">
                    <Send size={16} />
                    Send Message
                  </button>
                </form>
              )}

              {/* Direct contact options */}
              <div className="mt-7 flex flex-col sm:flex-row gap-3">
                <a
                  href="tel:+923318899227"
                  className="flex-1 flex items-center gap-3 bg-[#F0F7FF] hover:bg-sky-100 rounded-xl px-4 py-3 transition-colors"
                >
                  <div className="w-9 h-9 bg-sky-500 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Phone size={15} className="text-white" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-400 font-medium">Prefer to call?</p>
                    <p className="text-[#0B1D3A] font-bold text-sm">+92 331 8899227</p>
                  </div>
                </a>
                <a
                  href="https://wa.me/923318899227"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 flex items-center gap-3 bg-green-50 hover:bg-green-100 rounded-xl px-4 py-3 transition-colors"
                >
                  <div className="w-9 h-9 bg-[#25D366] rounded-lg flex items-center justify-center flex-shrink-0">
                    <svg viewBox="0 0 24 24" className="w-4 h-4 text-white" fill="currentColor">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                    </svg>
                  </div>
                  <div>
                    <p className="text-xs text-slate-400 font-medium">Chat instantly</p>
                    <p className="text-[#0B1D3A] font-bold text-sm">WhatsApp Us</p>
                  </div>
                </a>
              </div>
            </div>

            {/* ── HOURS & MAP ── */}
            <div className="space-y-7">
              {/* Working Hours */}
              <div className="bg-[#F0F7FF] rounded-2xl p-6">
                <div className="flex items-center gap-2 mb-5">
                  <Clock size={18} className="text-sky-500" />
                  <h3 className="font-bold text-[#0B1D3A] text-base" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                    Working Hours
                  </h3>
                </div>
                <div className="space-y-2.5">
                  {workingHours.map((h) => (
                    <div
                      key={h.day}
                      className={`flex justify-between items-center py-2.5 px-3 rounded-xl ${
                        h.day === todayName
                          ? 'bg-sky-500 text-white'
                          : 'bg-white'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className={`w-2 h-2 rounded-full flex-shrink-0 ${h.open ? (h.day === todayName ? 'bg-white' : 'bg-green-400') : 'bg-red-400'}`} />
                        <span className={`font-semibold text-sm ${h.day === todayName ? 'text-white' : 'text-[#0B1D3A]'}`}>
                          {h.day}
                          {h.day === todayName && <span className="text-white/80 font-normal ml-1 text-xs">(Today)</span>}
                        </span>
                      </div>
                      <span className={`text-sm font-medium ${!h.open ? 'text-red-500' : h.day === todayName ? 'text-white' : 'text-slate-600'}`}>
                        {h.hours}
                      </span>
                    </div>
                  ))}
                </div>
                <div className="mt-4 p-3 bg-sky-50 rounded-xl border border-sky-100">
                  <p className="text-xs text-sky-700 font-medium">
                    💡 <strong>Note:</strong> For emergency dental care outside clinic hours, please call or WhatsApp us immediately.
                  </p>
                </div>
              </div>

              {/* Google Maps Embed */}
              <div className="rounded-2xl overflow-hidden shadow-sm border border-slate-100">
                <div className="bg-[#0B1D3A] px-4 py-3 flex items-center gap-2">
                  <MapPin size={15} className="text-sky-400" />
                  <p className="text-white text-sm font-semibold">True Dental Care — I-8 Markaz, Islamabad</p>
                </div>
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3320.7929!2d73.0851!3d33.6844!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x38dfbfd07891722f%3A0x6789c5b7f3c6b14e!2sI-8%20Markaz%2C%20Islamabad%2C%20Islamabad%20Capital%20Territory%2C%20Pakistan!5e0!3m2!1sen!2s!4v1699000000000!5m2!1sen!2s"
                  width="100%"
                  height="300"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="True Dental Care Islamabad Location Map"
                  className="block"
                />
                <div className="p-4 bg-white border-t border-slate-100">
                  <p className="text-slate-500 text-xs mb-2">📍 Pakland Business Center, behind KFC, below Soneri Bank, I-8 Markaz, Islamabad, 44000</p>
                  <a
                    href="https://maps.google.com/?q=I-8+Markaz+Islamabad+Pakland+Business+Center"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-sky-500 hover:text-sky-600 font-semibold text-xs transition-colors"
                  >
                    Get Directions on Google Maps
                    <ArrowRight size={12} />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
