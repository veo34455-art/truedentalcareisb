import { useState } from 'react';
import { Link } from 'react-router-dom';
import { X, ZoomIn, ArrowRight } from 'lucide-react';

const galleryItems = [
  {
    src: '/images/hero-dental.jpg',
    alt: 'True Dental Care Islamabad - Modern dental clinic interior',
    label: 'Clinic Interior',
    category: 'clinic',
  },
  {
    src: '/images/gallery-1.jpg',
    alt: 'True Dental Care Islamabad - Welcoming reception area',
    label: 'Reception Area',
    category: 'clinic',
  },
  {
    src: '/images/gallery-3.jpg',
    alt: 'State-of-the-art dental treatment room at True Dental Care',
    label: 'Treatment Room',
    category: 'clinic',
  },
  {
    src: '/images/smiling-patient.jpg',
    alt: 'Happy patient after dental treatment at True Dental Care Islamabad',
    label: 'Happy Patient',
    category: 'patients',
  },
  {
    src: '/images/gallery-2.jpg',
    alt: 'Teeth whitening before and after results',
    label: 'Whitening Results',
    category: 'results',
  },
  {
    src: '/images/doctor-placeholder.jpg',
    alt: 'Dr. Wafa Abdi - Lead Dentist at True Dental Care Islamabad',
    label: 'Dr. Wafa Abdi',
    category: 'team',
  },
  {
    src: '/images/gallery-1.jpg',
    alt: 'Dental consultation room at True Dental Care I-8 Islamabad',
    label: 'Consultation Room',
    category: 'clinic',
  },
  {
    src: '/images/smiling-patient.jpg',
    alt: 'Successful smile transformation at True Dental Care',
    label: 'Smile Transformation',
    category: 'results',
  },
  {
    src: '/images/hero-dental.jpg',
    alt: 'Professional dental equipment at True Dental Care Islamabad',
    label: 'Modern Equipment',
    category: 'clinic',
  },
];

const categories = [
  { id: 'all', label: 'All Photos' },
  { id: 'clinic', label: 'Our Clinic' },
  { id: 'results', label: 'Treatment Results' },
  { id: 'patients', label: 'Happy Patients' },
  { id: 'team', label: 'Our Team' },
];

export default function Gallery() {
  const [activeFilter, setActiveFilter] = useState('all');
  const [lightbox, setLightbox] = useState<null | { src: string; alt: string; label: string }>(null);

  const filtered = activeFilter === 'all'
    ? galleryItems
    : galleryItems.filter((item) => item.category === activeFilter);

  return (
    <div className="pt-20">
      {/* ── PAGE HERO ── */}
      <section className="bg-gradient-to-br from-[#0B1D3A] via-[#1A3A6B] to-[#0EA5E9]/80 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-sky-400 font-semibold text-sm uppercase tracking-widest mb-3">See Our Work</p>
          <h1 className="text-4xl md:text-5xl font-extrabold text-white mb-4" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
            Gallery
          </h1>
          <p className="text-slate-300 max-w-xl mx-auto text-base leading-relaxed">
            Take a visual tour of our clinic, meet our team, and see the smile transformations we've achieved for our patients in Islamabad.
          </p>
          <div className="flex justify-center gap-2 mt-6 text-slate-400 text-sm">
            <Link to="/" className="hover:text-sky-400 transition-colors">Home</Link>
            <span>/</span>
            <span className="text-sky-400">Gallery</span>
          </div>
        </div>
      </section>

      {/* ── GALLERY ── */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Filter tabs */}
          <div className="flex flex-wrap gap-3 justify-center mb-10">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveFilter(cat.id)}
                className={`px-5 py-2.5 rounded-full font-semibold text-sm transition-all duration-200 ${
                  activeFilter === cat.id
                    ? 'bg-sky-500 text-white shadow-lg shadow-sky-200'
                    : 'bg-slate-100 text-slate-600 hover:bg-sky-50 hover:text-sky-600'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5">
            {filtered.map((item, i) => (
              <div
                key={i}
                className="gallery-item relative rounded-2xl overflow-hidden cursor-pointer group shadow-sm hover:shadow-xl transition-shadow duration-300"
                style={{ aspectRatio: i % 5 === 0 ? '4/3' : '1/1' }}
                onClick={() => setLightbox(item)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => e.key === 'Enter' && setLightbox(item)}
                aria-label={`View ${item.label}`}
              >
                <img
                  src={item.src}
                  alt={item.alt}
                  className="w-full h-full object-cover"
                  loading="lazy"
                  style={{ aspectRatio: i % 5 === 0 ? '4/3' : '1/1', minHeight: '220px', objectFit: 'cover', width: '100%', height: '100%' }}
                />
                {/* Overlay */}
                <div className="gallery-overlay absolute inset-0 bg-gradient-to-t from-[#0B1D3A]/80 via-[#0B1D3A]/20 to-transparent flex flex-col justify-end p-4">
                  <div className="flex items-center justify-between">
                    <span className="text-white font-bold text-sm">{item.label}</span>
                    <div className="w-8 h-8 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
                      <ZoomIn size={14} className="text-white" />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Empty state */}
          {filtered.length === 0 && (
            <div className="text-center py-16 text-slate-400">
              <div className="text-5xl mb-4">📷</div>
              <p className="font-medium">No photos in this category yet. Check back soon!</p>
            </div>
          )}
        </div>
      </section>

      {/* ── BEFORE & AFTER CTA ── */}
      <section className="py-16 bg-[#F0F7FF]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="section-subheading">Upload Your Own</p>
          <h2 className="section-heading mb-4">Share Your Smile Story</h2>
          <p className="text-slate-500 mb-8 leading-relaxed">
            Did we transform your smile? We'd love to feature your before-and-after photos in our gallery (with your permission). Send your photos directly to us on WhatsApp and join our community of happy patients.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="https://wa.me/923318899227?text=Hello%2C%20I'd%20like%20to%20share%20my%20before-and-after%20smile%20photos%20with%20True%20Dental%20Care."
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-[#25D366] hover:bg-[#20b857] text-white font-bold px-8 py-4 rounded-full transition-all hover:scale-105 text-base shadow-lg"
            >
              <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
              Share on WhatsApp
            </a>
            <Link to="/appointments" className="btn-navy text-base py-4 px-8">
              Book Your Smile Journey
              <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>

      {/* ── LIGHTBOX ── */}
      {lightbox && (
        <div
          className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setLightbox(null)}
        >
          <div className="relative max-w-4xl w-full" onClick={(e) => e.stopPropagation()}>
            <button
              onClick={() => setLightbox(null)}
              className="absolute -top-12 right-0 text-white hover:text-sky-400 transition-colors"
              aria-label="Close lightbox"
            >
              <X size={28} />
            </button>
            <img
              src={lightbox.src}
              alt={lightbox.alt}
              className="w-full max-h-[80vh] object-contain rounded-2xl shadow-2xl"
            />
            <p className="text-center text-white/80 text-sm mt-4 font-medium">{lightbox.label}</p>
          </div>
        </div>
      )}
    </div>
  );
}
