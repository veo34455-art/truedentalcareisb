import { useState } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2, Clock, Phone, MapPin, ArrowRight } from 'lucide-react';

const services = [
  'Teeth Cleaning & Scaling',
  'Teeth Whitening',
  'Dental Filling (Cavity)',
  'Root Canal Treatment',
  'Orthodontic Braces Consultation',
  'Dental Implant Consultation',
  'Emergency Dental Care',
  'General Consultation / Check-up',
  'Other (Please describe in message)',
];

const timeSlots = [
  '1:00 PM', '1:30 PM', '2:00 PM', '2:30 PM', '3:00 PM', '3:30 PM',
  '4:00 PM', '4:30 PM', '5:00 PM', '5:30 PM', '6:00 PM', '6:30 PM',
  '7:00 PM', '7:30 PM',
];

export default function Appointments() {
  const [form, setForm] = useState({
    name: '',
    phone: '',
    email: '',
    service: '',
    date: '',
    time: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = 'Full name is required.';
    if (!form.phone.trim()) e.phone = 'Phone number is required.';
    else if (!/^[0-9+\s\-()]{7,15}$/.test(form.phone)) e.phone = 'Please enter a valid phone number.';
    if (!form.service) e.service = 'Please select a service.';
    if (!form.date) e.date = 'Please select a preferred date.';
    if (!form.time) e.time = 'Please select a preferred time.';
    return e;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    if (errors[e.target.name]) setErrors({ ...errors, [e.target.name]: '' });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }
    setSubmitted(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Minimum date = today
  const today = new Date().toISOString().split('T')[0];

  // Build WhatsApp message
  const waText = encodeURIComponent(
    `Hello! I'd like to book an appointment at True Dental Care Islamabad.\n\nService: ${form.service || '[Please mention service]'}\nDate: ${form.date || '[Please mention date]'}\nTime: ${form.time || '[Please mention time]'}\nName: ${form.name || '[Your name]'}`
  );

  return (
    <div className="pt-20">
      {/* ── PAGE HERO ── */}
      <section className="bg-gradient-to-br from-[#0B1D3A] via-[#1A3A6B] to-[#0EA5E9]/80 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-sky-400 font-semibold text-sm uppercase tracking-widest mb-3">Get Started</p>
          <h1 className="text-4xl md:text-5xl font-extrabold text-white mb-4" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
            Book Your Appointment
          </h1>
          <p className="text-slate-300 max-w-xl mx-auto text-base leading-relaxed">
            Schedule your visit with Dr. Wafa Abdi in minutes. Choose your service, pick a time, and we'll confirm within hours.
          </p>
          <div className="flex justify-center gap-2 mt-6 text-slate-400 text-sm">
            <Link to="/" className="hover:text-sky-400 transition-colors">Home</Link>
            <span>/</span>
            <span className="text-sky-400">Appointments</span>
          </div>
        </div>
      </section>

      <section className="py-16 bg-[#F0F7FF]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-10">
            {/* ── BOOKING FORM ── */}
            <div className="lg:col-span-2">
              {submitted ? (
                /* ── SUCCESS STATE ── */
                <div className="bg-white rounded-3xl p-10 shadow-sm border border-slate-100 text-center">
                  <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <CheckCircle2 size={40} className="text-green-500" />
                  </div>
                  <h2 className="text-2xl font-extrabold text-[#0B1D3A] mb-3" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                    Appointment Request Received!
                  </h2>
                  <p className="text-slate-500 mb-2 text-base leading-relaxed">
                    Thank you, <strong>{form.name}</strong>! Your appointment request for <strong>{form.service}</strong> on <strong>{form.date}</strong> at <strong>{form.time}</strong> has been submitted.
                  </p>
                  <p className="text-slate-500 mb-8 text-sm">
                    Our team will call you at <strong>{form.phone}</strong> to confirm your booking within 2–4 hours during clinic hours. You can also reach us directly on WhatsApp for immediate confirmation.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    <button
                      onClick={() => { setSubmitted(false); setForm({ name: '', phone: '', email: '', service: '', date: '', time: '', message: '' }); }}
                      className="btn-outline"
                    >
                      Book Another Appointment
                    </button>
                    <a
                      href={`https://wa.me/923318899227?text=${waText}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 bg-[#25D366] hover:bg-[#20b857] text-white font-semibold px-6 py-3 rounded-full transition-all hover:scale-105 shadow-md"
                    >
                      <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor">
                        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                      </svg>
                      Confirm via WhatsApp
                    </a>
                  </div>
                </div>
              ) : (
                /* ── BOOKING FORM ── */
                <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100">
                  <h2 className="text-xl font-extrabold text-[#0B1D3A] mb-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                    Schedule Your Visit
                  </h2>
                  <p className="text-slate-500 text-sm mb-7">
                    Fill in your details below. We'll confirm your appointment by phone within a few hours.
                  </p>

                  <form onSubmit={handleSubmit} className="space-y-5">
                    {/* Name & Phone */}
                    <div className="grid sm:grid-cols-2 gap-5">
                      <div>
                        <label className="text-xs font-bold text-[#0B1D3A] uppercase tracking-wider mb-1.5 block">
                          Full Name <span className="text-red-400">*</span>
                        </label>
                        <input
                          type="text"
                          name="name"
                          value={form.name}
                          onChange={handleChange}
                          placeholder="e.g. Ahmed Khan"
                          className={`form-input ${errors.name ? 'border-red-400 focus:ring-red-300' : ''}`}
                        />
                        {errors.name && <p className="text-red-400 text-xs mt-1">{errors.name}</p>}
                      </div>
                      <div>
                        <label className="text-xs font-bold text-[#0B1D3A] uppercase tracking-wider mb-1.5 block">
                          Phone Number <span className="text-red-400">*</span>
                        </label>
                        <input
                          type="tel"
                          name="phone"
                          value={form.phone}
                          onChange={handleChange}
                          placeholder="e.g. 0331-8899227"
                          className={`form-input ${errors.phone ? 'border-red-400 focus:ring-red-300' : ''}`}
                        />
                        {errors.phone && <p className="text-red-400 text-xs mt-1">{errors.phone}</p>}
                      </div>
                    </div>

                    {/* Email */}
                    <div>
                      <label className="text-xs font-bold text-[#0B1D3A] uppercase tracking-wider mb-1.5 block">
                        Email Address <span className="text-slate-400 font-normal">(optional)</span>
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={form.email}
                        onChange={handleChange}
                        placeholder="e.g. patient@email.com"
                        className="form-input"
                      />
                    </div>

                    {/* Service Selection */}
                    <div>
                      <label className="text-xs font-bold text-[#0B1D3A] uppercase tracking-wider mb-1.5 block">
                        Select Service <span className="text-red-400">*</span>
                      </label>
                      <select
                        name="service"
                        value={form.service}
                        onChange={handleChange}
                        className={`form-input ${errors.service ? 'border-red-400 focus:ring-red-300' : ''}`}
                      >
                        <option value="">— Choose a dental service —</option>
                        {services.map((s) => (
                          <option key={s} value={s}>{s}</option>
                        ))}
                      </select>
                      {errors.service && <p className="text-red-400 text-xs mt-1">{errors.service}</p>}
                    </div>

                    {/* Date & Time */}
                    <div className="grid sm:grid-cols-2 gap-5">
                      <div>
                        <label className="text-xs font-bold text-[#0B1D3A] uppercase tracking-wider mb-1.5 block">
                          Preferred Date <span className="text-red-400">*</span>
                        </label>
                        <input
                          type="date"
                          name="date"
                          value={form.date}
                          onChange={handleChange}
                          min={today}
                          className={`form-input ${errors.date ? 'border-red-400 focus:ring-red-300' : ''}`}
                        />
                        {errors.date && <p className="text-red-400 text-xs mt-1">{errors.date}</p>}
                      </div>
                      <div>
                        <label className="text-xs font-bold text-[#0B1D3A] uppercase tracking-wider mb-1.5 block">
                          Preferred Time <span className="text-red-400">*</span>
                        </label>
                        <select
                          name="time"
                          value={form.time}
                          onChange={handleChange}
                          className={`form-input ${errors.time ? 'border-red-400 focus:ring-red-300' : ''}`}
                        >
                          <option value="">— Select a time slot —</option>
                          {timeSlots.map((t) => (
                            <option key={t} value={t}>{t}</option>
                          ))}
                        </select>
                        {errors.time && <p className="text-red-400 text-xs mt-1">{errors.time}</p>}
                      </div>
                    </div>

                    {/* Message */}
                    <div>
                      <label className="text-xs font-bold text-[#0B1D3A] uppercase tracking-wider mb-1.5 block">
                        Additional Notes <span className="text-slate-400 font-normal">(optional)</span>
                      </label>
                      <textarea
                        name="message"
                        value={form.message}
                        onChange={handleChange}
                        rows={3}
                        placeholder="Any specific concerns, symptoms, or questions for Dr. Wafa..."
                        className="form-input resize-none"
                      />
                    </div>

                    {/* Submit */}
                    <div className="pt-2">
                      <button type="submit" className="btn-primary w-full justify-center text-base py-4">
                        Confirm Appointment Request
                        <ArrowRight size={18} />
                      </button>
                      <p className="text-slate-400 text-xs text-center mt-3">
                        Our team will call you to confirm within clinic hours (Mon–Sat, 1:00 PM – 8:00 PM).
                      </p>
                    </div>
                  </form>
                </div>
              )}

              {/* WhatsApp Quick Book */}
              <div className="mt-6 bg-[#25D366]/10 border border-[#25D366]/30 rounded-2xl p-5 flex flex-col sm:flex-row items-center gap-4">
                <div className="flex-shrink-0 w-12 h-12 bg-[#25D366] rounded-xl flex items-center justify-center">
                  <svg viewBox="0 0 24 24" className="w-6 h-6 text-white" fill="currentColor">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                  </svg>
                </div>
                <div className="flex-1 text-center sm:text-left">
                  <h4 className="font-bold text-[#0B1D3A] text-sm" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                    Prefer to Book via WhatsApp?
                  </h4>
                  <p className="text-slate-600 text-xs mt-0.5">
                    Send us a quick message and we'll schedule your appointment instantly.
                  </p>
                </div>
                <a
                  href="https://wa.me/923318899227?text=Hello%2C%20I%20would%20like%20to%20book%20an%20appointment%20at%20True%20Dental%20Care%20Islamabad."
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-shrink-0 bg-[#25D366] hover:bg-[#20b857] text-white font-bold px-5 py-2.5 rounded-full text-sm transition-all hover:scale-105"
                >
                  Book on WhatsApp
                </a>
              </div>
            </div>

            {/* ── SIDEBAR ── */}
            <div className="space-y-5">
              {/* Clinic Info */}
              <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
                <h3 className="font-bold text-[#0B1D3A] mb-4 text-base" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                  Clinic Information
                </h3>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-sky-50 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Phone size={14} className="text-sky-500" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Phone</p>
                      <a href="tel:+923318899227" className="text-[#0B1D3A] font-semibold text-sm hover:text-sky-500 transition-colors">
                        +92 331 8899227
                      </a>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-sky-50 rounded-lg flex items-center justify-center flex-shrink-0">
                      <MapPin size={14} className="text-sky-500" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Address</p>
                      <p className="text-[#0B1D3A] font-semibold text-sm">Pakland Business Center, behind KFC, below Soneri Bank, I-8 Markaz, Islamabad</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-sky-50 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Clock size={14} className="text-sky-500" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-400 font-semibold uppercase tracking-wider mb-1">Working Hours</p>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span className="text-slate-600">Mon–Thu, Sat</span>
                          <span className="text-[#0B1D3A] font-semibold">1:00–8:00 PM</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-600">Friday</span>
                          <span className="text-[#0B1D3A] font-semibold">3:00–8:00 PM</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-600">Sunday</span>
                          <span className="text-red-500 font-semibold">Closed</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* What to expect */}
              <div className="bg-[#0B1D3A] rounded-2xl p-6">
                <h3 className="font-bold text-white mb-4 text-base" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                  What to Expect
                </h3>
                <ul className="space-y-3">
                  {[
                    'Confirmation call within 2–4 hours',
                    'Friendly check-in at reception',
                    'Thorough examination by Dr. Wafa',
                    'Transparent treatment plan & pricing',
                    'Gentle, painless procedures',
                    'Post-treatment care instructions',
                  ].map((item, i) => (
                    <li key={i} className="flex items-start gap-2.5 text-slate-300 text-sm">
                      <CheckCircle2 size={14} className="text-sky-400 flex-shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Emergency */}
              <div className="bg-red-50 border border-red-200 rounded-2xl p-5">
                <h4 className="font-bold text-red-700 text-sm mb-2">⚠️ Dental Emergency?</h4>
                <p className="text-red-600 text-xs mb-3 leading-relaxed">
                  If you're experiencing severe tooth pain, swelling, or dental trauma — don't wait. Call us immediately or message on WhatsApp.
                </p>
                <a
                  href="tel:+923318899227"
                  className="inline-flex items-center gap-1.5 bg-red-500 hover:bg-red-600 text-white font-bold text-sm px-4 py-2 rounded-full transition-all"
                >
                  <Phone size={13} />
                  Call Now
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
