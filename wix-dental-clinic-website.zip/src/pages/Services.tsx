import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle2 } from 'lucide-react';

const services = [
  {
    emoji: '🦷',
    color: 'from-sky-400 to-cyan-400',
    bg: 'bg-sky-50',
    name: 'Teeth Cleaning',
    tagline: 'Prevention is Better Than Cure',
    desc: 'Professional dental cleaning (scaling and polishing) removes stubborn plaque and tartar buildup that regular brushing can\'t reach. Recommended every 6 months to prevent gum disease, cavities, and bad breath.',
    bullets: [
      'Supragingival and subgingival scaling',
      'Professional polishing and stain removal',
      'Fluoride treatment for cavity protection',
      'Personalized oral hygiene guidance',
    ],
    duration: '45–60 min',
  },
  {
    emoji: '✨',
    color: 'from-yellow-400 to-amber-300',
    bg: 'bg-yellow-50',
    name: 'Teeth Whitening',
    tagline: 'Brighten Your Smile Safely',
    desc: 'Our professional in-clinic whitening treatments safely lighten teeth by several shades in a single session. Using premium whitening agents and protective protocols, we deliver brilliant results without sensitivity.',
    bullets: [
      'In-clinic power whitening treatment',
      'Up to 8 shades whiter in one session',
      'Gum and enamel protection throughout',
      'Take-home maintenance kit included',
    ],
    duration: '60–90 min',
  },
  {
    emoji: '🩹',
    color: 'from-emerald-400 to-teal-400',
    bg: 'bg-emerald-50',
    name: 'Dental Fillings',
    tagline: 'Restore. Protect. Look Natural.',
    desc: 'We use tooth-colored composite resin fillings that blend seamlessly with your natural tooth color. Whether it\'s a new cavity or a replacement for old amalgam fillings, we restore your tooth\'s strength and appearance.',
    bullets: [
      'Composite (tooth-colored) fillings',
      'Minimal tooth reduction required',
      'Mercury-free, biocompatible materials',
      'Durable, long-lasting restoration',
    ],
    duration: '30–60 min',
  },
  {
    emoji: '🔬',
    color: 'from-blue-400 to-indigo-400',
    bg: 'bg-blue-50',
    name: 'Root Canal Treatment',
    tagline: 'Save Your Natural Tooth',
    desc: 'Root canal therapy is a highly effective, virtually painless procedure that saves a badly infected or damaged tooth. Using modern rotary instruments and local anesthesia, Dr. Wafa ensures a comfortable experience.',
    bullets: [
      'Local anesthesia for pain-free treatment',
      'Rotary endodontic instruments for precision',
      'Thorough cleaning and disinfection of canals',
      'Biocompatible root filling material',
    ],
    duration: '60–120 min',
  },
  {
    emoji: '😁',
    color: 'from-purple-400 to-pink-400',
    bg: 'bg-purple-50',
    name: 'Orthodontic Braces',
    tagline: 'Straighten Your Smile with Confidence',
    desc: 'Misaligned teeth affect both appearance and oral health. We offer traditional metal braces and ceramic braces to gradually correct crowding, spacing, overbites, and underbites for a permanently straight smile.',
    bullets: [
      'Traditional metal and ceramic braces',
      'Customized treatment planning',
      'Regular monthly adjustments included',
      'Post-treatment retainer provided',
    ],
    duration: '12–24 months',
  },
  {
    emoji: '🦴',
    color: 'from-sky-500 to-blue-500',
    bg: 'bg-sky-50',
    name: 'Dental Implants',
    tagline: 'The Permanent Tooth Replacement',
    desc: 'Dental implants are the gold standard for replacing missing teeth. A titanium post fuses with your jawbone to create a stable foundation for a natural-looking crown — restoring function and aesthetics for life.',
    bullets: [
      'Titanium implant with osseointegration',
      'Porcelain crown matched to your teeth',
      'Prevents bone loss after tooth extraction',
      'Long-lasting — potentially a lifetime solution',
    ],
    duration: '3–6 months total',
  },
  {
    emoji: '🚨',
    color: 'from-red-400 to-orange-400',
    bg: 'bg-red-50',
    name: 'Emergency Dental Care',
    tagline: 'Urgent Care When You Need It Most',
    desc: 'Dental emergencies don\'t wait for business hours. Whether it\'s a severe toothache, broken tooth, lost filling, or dental trauma — our team provides prompt, compassionate emergency dental care in Islamabad.',
    bullets: [
      'Same-day emergency appointments available',
      'Toothache and abscess treatment',
      'Broken or chipped tooth repair',
      'Lost filling or crown replacement',
    ],
    duration: 'ASAP',
  },
];

export default function Services() {
  return (
    <div className="pt-20">
      {/* ── PAGE HERO ── */}
      <section className="bg-gradient-to-br from-[#0B1D3A] via-[#1A3A6B] to-[#0EA5E9]/80 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-sky-400 font-semibold text-sm uppercase tracking-widest mb-3">Complete Oral Healthcare</p>
          <h1 className="text-4xl md:text-5xl font-extrabold text-white mb-4" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
            Our Dental Services
          </h1>
          <p className="text-slate-300 max-w-xl mx-auto text-base leading-relaxed">
            From preventive cleanings to advanced restorative treatments, True Dental Care Islamabad offers comprehensive dental services for every patient.
          </p>
          <div className="flex justify-center gap-2 mt-6 text-slate-400 text-sm">
            <Link to="/" className="hover:text-sky-400 transition-colors">Home</Link>
            <span>/</span>
            <span className="text-sky-400">Services</span>
          </div>
        </div>
      </section>

      {/* ── SERVICES GRID ── */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-7">
            {services.map((s, i) => (
              <div
                key={i}
                className="service-card bg-white rounded-2xl overflow-hidden shadow-sm border border-slate-100 hover:shadow-xl group"
              >
                {/* Card Header */}
                <div className={`${s.bg} px-6 pt-7 pb-5 relative overflow-hidden`}>
                  <div className={`absolute -top-6 -right-6 w-24 h-24 bg-gradient-to-br ${s.color} opacity-10 rounded-full`} />
                  <div className="text-5xl mb-3">{s.emoji}</div>
                  <h3 className="font-extrabold text-[#0B1D3A] text-xl mb-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
                    {s.name}
                  </h3>
                  <p className={`text-sm font-semibold bg-gradient-to-r ${s.color} bg-clip-text text-transparent`}>
                    {s.tagline}
                  </p>
                </div>

                {/* Card Body */}
                <div className="p-6">
                  <p className="text-slate-500 text-sm leading-relaxed mb-5">{s.desc}</p>

                  {/* Bullet points */}
                  <ul className="space-y-2 mb-5">
                    {s.bullets.map((b, bi) => (
                      <li key={bi} className="flex items-start gap-2.5 text-slate-600 text-sm">
                        <CheckCircle2 size={14} className="text-sky-400 flex-shrink-0 mt-0.5" />
                        <span>{b}</span>
                      </li>
                    ))}
                  </ul>

                  {/* Duration & CTA */}
                  <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                    <div>
                      <span className="text-xs text-slate-400 uppercase font-semibold tracking-wider">Duration</span>
                      <p className="text-[#0B1D3A] font-bold text-sm">{s.duration}</p>
                    </div>
                    <Link
                      to="/appointments"
                      className="btn-primary text-xs py-2 px-4"
                    >
                      Book Now
                      <ArrowRight size={13} />
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── WHY CHOOSE ── */}
      <section className="py-16 bg-[#F0F7FF]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="section-subheading">Before You Go</p>
          <h2 className="section-heading mb-4">Have Questions About a Procedure?</h2>
          <p className="text-slate-500 mb-8 leading-relaxed">
            Not sure which service you need? That's perfectly normal. Dr. Wafa Abdi offers personalized consultations where she'll evaluate your dental health and recommend the most suitable treatment plan — with no pressure.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/appointments" className="btn-primary text-base py-4 px-8">
              Book Free Consultation
              <ArrowRight size={18} />
            </Link>
            <a
              href="https://wa.me/923318899227?text=Hello%2C%20I%20have%20a%20question%20about%20a%20dental%20service."
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-[#25D366] hover:bg-[#20b857] text-white font-semibold px-8 py-4 rounded-full transition-all hover:scale-105 text-base shadow-lg"
            >
              <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
              Ask on WhatsApp
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
